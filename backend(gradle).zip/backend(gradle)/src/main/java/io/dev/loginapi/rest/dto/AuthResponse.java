package io.dev.loginapi.rest.dto;

public record AuthResponse(String accessToken) {
}
